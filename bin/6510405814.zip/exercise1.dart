void main() {
  double temperature = 20;
  int value = 2;
  String pizza = 'pizza';
  String pasta = 'pasta';

  print("""The temperature is ${temperature.toInt()}C
$value plus $value = ${value * 2}
I like $pizza and $pasta
""");
}
